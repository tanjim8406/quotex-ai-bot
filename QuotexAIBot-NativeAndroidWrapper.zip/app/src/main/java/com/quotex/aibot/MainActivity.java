package com.quotex.aibot;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.Locale;

/**
 * ============================================================================
 * Android 11 (API 30) MainActivity
 * Implements:
 * 1. MediaProjectionManager intent launch for explicit user screen capture consent
 * 2. ForegroundService startForeground() invocation with MediaProjection intent token
 * 3. SYSTEM_ALERT_WINDOW permission handling (Tecno HiOS, Vivo, Samsung optimized)
 * 4. High-performance WebView with WebChromeClient & JavaScript Bridge
 * ============================================================================
 */
public class MainActivity extends Activity {
    private static final String TAG = "QuotexMainActivity";
    public static final int REQUEST_OVERLAY_PERMISSION = 2001;
    public static final int REQUEST_MEDIA_PROJECTION = 2002;

    // TARGET HTTPS WEB APPLICATION URL
    public static final String TARGET_WEB_URL = "https://ais-pre-cixovbtdlsaxuzrifnni5r-712643767060.asia-southeast1.run.app";

    private static MainActivity instance;
    private WebView webView;
    private TextToSpeech tts;
    private boolean isTtsReady = false;
    private boolean isWaitingForOverlayPermission = false;

    public static MainActivity getInstance() {
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;

        // Fullscreen configuration
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        initViews();
        initTextToSpeech();
    }

    private void initViews() {
        webView = new WebView(this);
        setContentView(webView);

        configureWebView(webView);
        webView.loadUrl(TARGET_WEB_URL);
    }

    private void configureWebView(WebView view) {
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        // Hardware Acceleration
        view.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // Inject Native JavaScript Bridge
        view.addJavascriptInterface(new AndroidNativeBridge(this), "AndroidBridge");

        // Native WebViewClient
        view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false;
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                } catch (Exception e) {
                    return true;
                }
            }

            @Override
            public void onPageFinished(WebView webView, String url) {
                super.onPageFinished(webView, url);
                Log.d(TAG, "WebView page loaded successfully: " + url);
            }
        });

        // WebChromeClient Override for Native Permissions
        view.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        request.grant(request.getResources());
                    }
                });
            }
        });
    }

    private void initTextToSpeech() {
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = tts.setLanguage(new Locale("bn", "BD"));
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts.setLanguage(Locale.US);
                    }
                    isTtsReady = true;
                }
            }
        });
    }

    public void speakBengali(String text) {
        if (tts != null && isTtsReady && text != null && !text.isEmpty()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "quotex_signal");
            } else {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            }
        }
    }

    /**
     * Check if app already has SYSTEM_ALERT_WINDOW permission
     */
    public boolean hasOverlayPermission() {
        return PermissionManager.hasOverlayPermission(this);
    }

    /**
     * Check overlay permission first, then launch screen capture intent
     */
    public void checkPermissionsAndStartOverlay() {
        PermissionManager.checkAndRequestOverlayPermission(this, new PermissionManager.PermissionCallback() {
            @Override
            public void onGranted() {
                requestScreenCapturePermissionWithDialog();
            }

            @Override
            public void onDenied() {
                // Even if overlay is denied, allow screen capture for inside-app analysis
                requestScreenCapturePermissionWithDialog();
            }
        });
    }

    /**
     * Launch MediaProjectionManager intent to ask the user for explicit screen capture consent.
     * Shows a clear explanation dialog before launching the system consent popup.
     */
    public void requestScreenCapturePermissionWithDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("📱 স্ক্রিন শেয়ার ও চার্ট ক্যাপচার অনুমতি");
                builder.setMessage(
                        "কোয়াটেক্স চার্ট সরাসরি স্ক্যান এবং এআই সংকেত পাওয়ার জন্য স্ক্রিন ক্যাপচার অনুমতি প্রয়োজন।\n\n" +
                        "পরবর্তী সিস্টেম পপ-আপে 'Start now' বা 'শুরু করুন' নির্বাচন করুন।"
                );
                builder.setPositiveButton("সম্মতি দিন (Allow)", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        launchMediaProjectionIntent();
                    }
                });
                builder.setNegativeButton("বাতিল", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "স্ক্রিন ক্যাপচার ছাড়া লাইভ চার্ট অ্যানালাইসিস সম্ভব নয়।", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setCancelable(false);
                builder.show();
            }
        });
    }

    /**
     * Directly launches the MediaProjection consent dialog
     */
    public void launchMediaProjectionIntent() {
        MediaProjectionManager projectionManager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        if (projectionManager != null) {
            Intent captureIntent = projectionManager.createScreenCaptureIntent();
            startActivityForResult(captureIntent, REQUEST_MEDIA_PROJECTION);
        } else {
            Toast.makeText(this, "MediaProjection সার্ভিস পাওয়া যায়নি।", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Open SYSTEM_ALERT_WINDOW settings screen with HiOS / Tecno / Vivo fallback
     */
    public void openOverlaySettings() {
        isWaitingForOverlayPermission = true;
        PermissionManager.openOverlaySettings(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        PermissionManager.handleOnResume(this, new PermissionManager.PermissionCallback() {
            @Override
            public void onGranted() {
                if (isWaitingForOverlayPermission) {
                    isWaitingForOverlayPermission = false;
                    Toast.makeText(MainActivity.this, "✅ ডিসপ্লে ওভারলে অনুমতি সক্রিয় হয়েছে!", Toast.LENGTH_SHORT).show();
                    requestScreenCapturePermissionWithDialog();
                }
            }

            @Override
            public void onDenied() {
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            isWaitingForOverlayPermission = false;
            PermissionManager.handleActivityResult(this, requestCode, resultCode, new PermissionManager.PermissionCallback() {
                @Override
                public void onGranted() {
                    Toast.makeText(MainActivity.this, "✅ ওভারলে অনুমতি সক্রিয়!", Toast.LENGTH_SHORT).show();
                    requestScreenCapturePermissionWithDialog();
                }

                @Override
                public void onDenied() {
                    Toast.makeText(MainActivity.this, "ভাসমান পারমিশন সক্রিয় করা হয়নি।", Toast.LENGTH_SHORT).show();
                }
            });
        } else if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                // ============================================================
                // Launch Android 11 ForegroundService with MediaProjection Token
                // ============================================================
                Intent serviceIntent = new Intent(this, ForegroundService.class);
                serviceIntent.putExtra(ForegroundService.EXTRA_RESULT_CODE, resultCode);
                serviceIntent.putExtra(ForegroundService.EXTRA_DATA_INTENT, data);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }

                Toast.makeText(this, "✅ স্ক্রিন শেয়ার সফল! এবার কোয়াটেক্স চার্ট ওপেন করুন।", Toast.LENGTH_LONG).show();

                // Notify WebView that native screen capture is running
                if (webView != null) {
                    webView.evaluateJavascript("if (window.onNativeScreenCaptureStarted) { window.onNativeScreenCaptureStarted(); }", null);
                }
            } else {
                Toast.makeText(this, "স্ক্রিন ক্যাপচার অনুমতি বাতিল করা হয়েছে।", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void stopForegroundService() {
        Intent serviceIntent = new Intent(this, ForegroundService.class);
        stopService(serviceIntent);
        Toast.makeText(this, "স্ক্রিন ক্যাপচার ও ভাসমান বট বন্ধ করা হয়েছে।", Toast.LENGTH_SHORT).show();
        if (webView != null) {
            webView.evaluateJavascript("if (typeof window !== 'undefined' && window.onNativeScreenCaptureStopped) { window.onNativeScreenCaptureStopped(); }", null);
        }
    }

    /**
     * Send Base64 screen capture frame directly to WebView JS context window.onNativeScreenCaptured
     */
    public static void sendFrameToWebView(final String base64Image) {
        if (instance == null || instance.webView == null || base64Image == null) return;

        instance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    String clean = base64Image.trim();
                    String js = "if (typeof window !== 'undefined' && window.onNativeScreenCaptured) { window.onNativeScreenCaptured('" + clean + "'); }";
                    instance.webView.evaluateJavascript(js, new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            Log.d(TAG, "WebView onNativeScreenCaptured delivered");
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "sendFrameToWebView error: " + e.getMessage());
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        instance = null;
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (webView != null) {
            webView.destroy();
        }
    }
}
