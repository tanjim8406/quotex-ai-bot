package com.quotex.aibot;

import android.webkit.JavascriptInterface;

/**
 * Bidirectional JavaScript Bridge between Native Android and the HTTPS Web Application.
 * Seamlessly connects Web UI actions (Screen Share, Floating HUD, Signals) with Android 11 MediaProjection and Overlay APIs.
 */
public class AndroidNativeBridge {
    private final MainActivity activity;

    public AndroidNativeBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public boolean isNativeApp() {
        return true;
    }

    @JavascriptInterface
    public boolean hasOverlayPermission() {
        return activity.hasOverlayPermission();
    }

    @JavascriptInterface
    public void openOverlaySettings() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                activity.openOverlaySettings();
            }
        });
    }

    /**
     * Request Screen Capture & Overlay:
     * If SYSTEM_ALERT_WINDOW (Display over other apps) is not granted,
     * it automatically opens the explanation dialog and takes user to Settings!
     * Once granted, it launches the MediaProjection consent dialog and ForegroundService.
     */
    @JavascriptInterface
    public void requestScreenCapture() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (!activity.hasOverlayPermission()) {
                    activity.checkPermissionsAndStartOverlay();
                } else {
                    activity.requestScreenCapturePermissionWithDialog();
                }
            }
        });
    }

    @JavascriptInterface
    public void startFloatingOverlay() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                activity.checkPermissionsAndStartOverlay();
            }
        });
    }

    @JavascriptInterface
    public void stopFloatingOverlay() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                activity.stopForegroundService();
            }
        });
    }

    @JavascriptInterface
    public void triggerNativeCapture() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (ForegroundService.getInstance() == null) {
                    activity.requestScreenCapturePermissionWithDialog();
                } else {
                    ForegroundService.triggerScreenCapture();
                }
            }
        });
    }

    @JavascriptInterface
    public void onSignalResult(final String jsonString) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ForegroundService.updateSignalDisplay(jsonString);
            }
        });
    }

    @JavascriptInterface
    public void speakVoice(final String text) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                activity.speakBengali(text);
            }
        });
    }
}
