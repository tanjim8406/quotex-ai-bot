package com.quotex.aibot;

/**
 * Backward compatibility alias for ForegroundService.
 * Extends ForegroundService so any intent or reference to FloatingOverlayService
 * performs the exact same Android 11 MediaProjection foreground service operations.
 */
public class FloatingOverlayService extends ForegroundService {
    // Inherits all MediaProjection, startForeground notification, and floating overlay logic.
}
