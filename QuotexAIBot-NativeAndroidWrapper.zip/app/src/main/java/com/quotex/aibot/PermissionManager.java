package com.quotex.aibot;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import java.lang.reflect.Method;

/**
 * =============================================================================
 * PermissionManager.java - Robust SYSTEM_ALERT_WINDOW ("Display Over Other Apps")
 * =============================================================================
 * Specially designed for Android 11 (API 30), Android 12, 13, 14+
 * Handles device-specific quirks for:
 *  - Tecno & Infinix (HiOS / XOS / Transsion)
 *  - Vivo & iQOO (Funtouch OS / OriginOS / iManager)
 *  - Samsung (One UI / Appear On Top)
 *  - Xiaomi / Redmi / POCO (MIUI / HyperOS)
 *
 * Utilizes multi-tier Intent flag variations, AppOps fallback verification,
 * and OEM-tailored custom dialog triggers.
 * =============================================================================
 */
public class PermissionManager {
    private static final String TAG = "PermissionManager";

    // Request code for starting overlay settings intent
    public static final int REQUEST_OVERLAY_PERMISSION = 2001;

    // State tracking when an Activity has dispatched the user to Settings
    private static boolean isWaitingForOverlayPermission = false;

    /**
     * Callback interface for permission state changes
     */
    public interface PermissionCallback {
        void onGranted();
        void onDenied();
    }

    /**
     * Check if "Display over other apps" (SYSTEM_ALERT_WINDOW) is granted.
     * Uses both standard Settings.canDrawOverlays and secondary AppOpsManager check
     * to prevent false-negative returns on Tecno HiOS, Vivo, and Samsung devices.
     *
     * @param context Application or Activity context
     * @return true if permission is active and granted, false otherwise.
     */
    public static boolean hasOverlayPermission(Context context) {
        if (context == null) return false;

        // Android versions prior to Marshmallow (API 23) grant this upon installation
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }

        // Tier 1: Official Android API
        try {
            if (Settings.canDrawOverlays(context)) {
                return true;
            }
        } catch (Exception e) {
            Log.w(TAG, "Settings.canDrawOverlays check threw exception: " + e.getMessage());
        }

        // Tier 2: AppOpsManager secondary verification (crucial for Vivo & Tecno HiOS)
        return checkAppOpsPermission(context);
    }

    /**
     * Deep AppOpsManager check to verify the OP_SYSTEM_ALERT_WINDOW operation mode.
     */
    public static boolean checkAppOpsPermission(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            return true;
        }

        try {
            AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;

            int uid = Process.myUid();
            String pkg = context.getPackageName();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int mode = appOps.checkOpNoThrow(
                        AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                        uid,
                        pkg
                );
                return mode == AppOpsManager.MODE_ALLOWED;
            } else {
                // Pre-M reflection for OP_SYSTEM_ALERT_WINDOW (op code 24)
                Class<?> clazz = AppOpsManager.class;
                Method checkOpMethod = clazz.getMethod("checkOpNoThrow", Integer.TYPE, Integer.TYPE, String.class);
                int mode = (Integer) checkOpMethod.invoke(appOps, 24, uid, pkg);
                return mode == AppOpsManager.MODE_ALLOWED;
            }
        } catch (Exception e) {
            Log.w(TAG, "AppOps checkOpNoThrow failed: " + e.getMessage());
        }
        return false;
    }

    /**
     * Checks permission and shows a tailored custom Dialog pop-up if not granted.
     *
     * @param activity Hosting Activity
     * @param callback Callback executed when granted or denied
     */
    public static void checkAndRequestOverlayPermission(final Activity activity, final PermissionCallback callback) {
        if (activity == null) return;

        if (hasOverlayPermission(activity)) {
            Log.i(TAG, "Overlay permission is already granted.");
            if (callback != null) callback.onGranted();
        } else {
            showOverlayPermissionDialog(activity, callback);
        }
    }

    /**
     * Displays a custom Dialog pop-up explaining why the permission is needed.
     * The dialog title and instructions dynamically adapt to the user's phone brand
     * (Tecno HiOS, Vivo, Samsung, or Standard).
     */
    public static void showOverlayPermissionDialog(final Activity activity, final PermissionCallback callback) {
        if (activity == null || activity.isFinishing()) return;

        String brand = Build.MANUFACTURER.toUpperCase();
        String title;
        String message;

        if (isTecno()) {
            title = "📱 Tecno / HiOS: 'Display Over Other Apps'";
            message = "Tecno (HiOS / Phone Master) ডিভাইসে কোয়াটেক্স ও অন্যান্য ট্রেডিং অ্যাপের উপর ভাসমান AI সংকেত বাটন সক্রিয় রাখতে 'Display over other apps' অনুমতি দিন।\n\n'সেটিংস খুলুন' ট্যাপ করে 'Quotex AI Bot' এর পাশের টগলটি চালু করুন।";
        } else if (isVivo()) {
            title = "📱 Vivo: 'Floating Window' পারমিশন";
            message = "Vivo (Funtouch OS / OriginOS) ডিভাইসে Quotex চার্টের উপর ভাসমান এআই সিগন্যাল HUD চালু রাখতে 'Display over other apps' / 'Floating window' অনুমতি প্রয়োজন।\n\n'সেটিংস খুলুন' চেপে পারমিশনটি অন করুন।";
        } else if (isSamsung()) {
            title = "📱 Samsung: 'Appear on top' পারমিশন";
            message = "Samsung (One UI - Android 11+) ডিভাইসে ট্রেডিং স্ক্রিনের উপর ভাসমান বাটন সক্রিয় রাখতে 'Appear on top' (অন্যান্য অ্যাপের উপরে দেখান) সুইচটি অন করুন।\n\n'সেটিংস খুলুন' চেপে টগলটি সক্রিয় করুন।";
        } else if (isXiaomi()) {
            title = "📱 Xiaomi / MIUI: 'Display Pop-up Window'";
            message = "MIUI / HyperOS ডিভাইসে ভাসমান বাটন ও এআই সংকেত দেখানোর জন্য 'Display pop-up windows while running in the background' অনুমতি চালু করুন।\n\n'সেটিংস খুলুন' ট্যাপ করুন।";
        } else {
            title = "📱 ডিসপ্লে ওভারলে অনুমতি প্রয়োজন (" + brand + ")";
            message = "কোয়াটেক্স (Quotex) বা যেকোনো অ্যাপের উপর ভাসমান AI সিগন্যাল ও চার্ট স্ক্যান বাটন স্থায়ীভাবে প্রদর্শন করতে 'Display over other apps' অনুমতি সক্রিয় করুন।\n\n'সেটিংস খুলুন' চেপে টগলটি অন করুন।";
        }

        new AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("সেটিংস খুলুন (Open Settings)", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openOverlaySettings(activity);
                    }
                })
                .setNegativeButton("পরে করব (Later)", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Toast.makeText(activity, "ভাসমান বাটন চালু করতে ওভারলে অনুমতি আবশ্যক।", Toast.LENGTH_LONG).show();
                        if (callback != null) callback.onDenied();
                    }
                })
                .setCancelable(false)
                .show();
    }

    /**
     * Resiliently launches the system overlay settings screen.
     * Incorporates custom Intent flag variations and multi-tier fallbacks:
     *  - Tier 1: OEM-specific direct permission managers (Tecno, Vivo, Xiaomi)
     *  - Tier 2: Settings.ACTION_MANAGE_OVERLAY_PERMISSION with package URI & Intent flag variations
     *  - Tier 3: Generic Settings.ACTION_MANAGE_OVERLAY_PERMISSION without package URI
     *  - Tier 4: Settings.ACTION_APPLICATION_DETAILS_SETTINGS (App Info)
     *  - Tier 5: General System Settings
     *
     * @param activity Current Activity
     */
    public static void openOverlaySettings(Activity activity) {
        if (activity == null) return;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;

        isWaitingForOverlayPermission = true;
        String packageName = activity.getPackageName();

        // ---------------------------------------------------------------------
        // OEM QUIRK 1: VIVO (Funtouch OS / OriginOS / iQOO)
        // ---------------------------------------------------------------------
        if (isVivo()) {
            // Intent Variation 1: Vivo Permission Manager
            try {
                Intent vivoIntent = new Intent();
                vivoIntent.setClassName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.PurviewTabActivity");
                vivoIntent.putExtra("packagename", packageName);
                vivoIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                activity.startActivityForResult(vivoIntent, REQUEST_OVERLAY_PERMISSION);
                Log.d(TAG, "Launched Vivo PurviewTabActivity successfully.");
                return;
            } catch (Exception e) {
                Log.w(TAG, "Vivo PurviewTabActivity intent failed: " + e.getMessage());
            }

            // Intent Variation 2: iQOO Secure Floating Window Manager
            try {
                Intent iqooIntent = new Intent();
                iqooIntent.setClassName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.FloatWindowManager");
                iqooIntent.putExtra("packagename", packageName);
                iqooIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivityForResult(iqooIntent, REQUEST_OVERLAY_PERMISSION);
                Log.d(TAG, "Launched iQOO FloatWindowManager successfully.");
                return;
            } catch (Exception e) {
                Log.w(TAG, "iQOO FloatWindowManager intent failed: " + e.getMessage());
            }
        }

        // ---------------------------------------------------------------------
        // OEM QUIRK 2: TECNO & INFINIX (HiOS / XOS / Transsion)
        // ---------------------------------------------------------------------
        if (isTecno()) {
            // Try Transsion Phone Master permission intent
            try {
                Intent tecnoIntent = new Intent();
                tecnoIntent.setComponent(new ComponentName(
                        "com.transsion.phonemaster",
                        "com.transsion.phonemaster.PermissionManagerActivity"
                ));
                tecnoIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                activity.startActivityForResult(tecnoIntent, REQUEST_OVERLAY_PERMISSION);
                Log.d(TAG, "Launched Tecno PhoneMaster PermissionManagerActivity.");
                return;
            } catch (Exception e) {
                Log.w(TAG, "Tecno PhoneMaster intent failed, falling back to package overlay intent: " + e.getMessage());
            }
        }

        // ---------------------------------------------------------------------
        // OEM QUIRK 3: XIAOMI / REDMI / POCO (MIUI / HyperOS)
        // ---------------------------------------------------------------------
        if (isXiaomi()) {
            try {
                Intent miuiIntent = new Intent("miui.intent.action.APP_PERM_EDITOR");
                miuiIntent.setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity");
                miuiIntent.putExtra("extra_pkgname", packageName);
                miuiIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                activity.startActivityForResult(miuiIntent, REQUEST_OVERLAY_PERMISSION);
                Log.d(TAG, "Launched MIUI APP_PERM_EDITOR successfully.");
                return;
            } catch (Exception e) {
                Log.w(TAG, "MIUI permission editor intent failed: " + e.getMessage());
            }
        }

        // ---------------------------------------------------------------------
        // TIER 2: Standard ACTION_MANAGE_OVERLAY_PERMISSION with package URI
        // Tested for Android 11 (API 30), Samsung One UI, & general devices
        // ---------------------------------------------------------------------

        // Flag Variation A: Standard Task flags
        try {
            Intent intent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + packageName)
            );
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            activity.startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
            Log.d(TAG, "Launched ACTION_MANAGE_OVERLAY_PERMISSION with package URI & CLEAR_TOP.");
            return;
        } catch (ActivityNotFoundException | SecurityException e) {
            Log.w(TAG, "Package overlay intent with flags failed: " + e.getMessage());
        }

        // Flag Variation B: Pure Intent without extra flags
        try {
            Intent plainIntent = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + packageName)
            );
            activity.startActivityForResult(plainIntent, REQUEST_OVERLAY_PERMISSION);
            Log.d(TAG, "Launched plain ACTION_MANAGE_OVERLAY_PERMISSION with package URI.");
            return;
        } catch (ActivityNotFoundException | SecurityException e) {
            Log.w(TAG, "Plain package overlay intent failed: " + e.getMessage());
        }

        // ---------------------------------------------------------------------
        // TIER 3: Generic Settings.ACTION_MANAGE_OVERLAY_PERMISSION (All Apps list)
        // ---------------------------------------------------------------------
        try {
            Intent genericIntent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            genericIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivityForResult(genericIntent, REQUEST_OVERLAY_PERMISSION);
            Log.d(TAG, "Launched generic ACTION_MANAGE_OVERLAY_PERMISSION list.");
            return;
        } catch (ActivityNotFoundException | SecurityException e) {
            Log.w(TAG, "Generic overlay intent failed: " + e.getMessage());
        }

        // ---------------------------------------------------------------------
        // TIER 4: Application Details Settings (App Info)
        // ---------------------------------------------------------------------
        try {
            Intent appDetailsIntent = new Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + packageName)
            );
            appDetailsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivityForResult(appDetailsIntent, REQUEST_OVERLAY_PERMISSION);
            Log.d(TAG, "Launched ACTION_APPLICATION_DETAILS_SETTINGS.");
            return;
        } catch (Exception ex) {
            Log.w(TAG, "App details intent failed: " + ex.getMessage());
        }

        // ---------------------------------------------------------------------
        // TIER 5: General System Settings fallback
        // ---------------------------------------------------------------------
        try {
            Intent systemSettings = new Intent(Settings.ACTION_SETTINGS);
            systemSettings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(systemSettings);
            Toast.makeText(activity, "Settings > Apps > Special App Access > Display Over Other Apps এ গিয়ে অনুমতি অন করুন।", Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Log.e(TAG, "All intent attempts failed: " + ex.getMessage(), ex);
            Toast.makeText(activity, "সেটিংস পেজ খোলা যায়নি। দয়া করে ম্যানুয়ালি পারমিশন দিন।", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Call this inside Activity's onResume() to verify if the user granted
     * permission after returning from the settings screen.
     */
    public static void handleOnResume(Activity activity, PermissionCallback callback) {
        if (activity == null) return;

        if (isWaitingForOverlayPermission) {
            if (hasOverlayPermission(activity)) {
                isWaitingForOverlayPermission = false;
                Log.i(TAG, "Overlay permission confirmed granted onResume.");
                Toast.makeText(activity, "✅ 'Display over other apps' অনুমতি কার্যকর হয়েছে!", Toast.LENGTH_SHORT).show();
                if (callback != null) callback.onGranted();
            }
        }
    }

    /**
     * Call this inside Activity's onActivityResult() to handle the result
     * when the overlay settings screen finishes.
     */
    public static void handleActivityResult(Activity activity, int requestCode, int resultCode, PermissionCallback callback) {
        if (activity == null) return;

        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            isWaitingForOverlayPermission = false;
            if (hasOverlayPermission(activity)) {
                Log.i(TAG, "Overlay permission confirmed granted onActivityResult.");
                Toast.makeText(activity, "✅ 'Display over other apps' অনুমতি সক্রিয় করা হয়েছে!", Toast.LENGTH_SHORT).show();
                if (callback != null) callback.onGranted();
            } else {
                Log.w(TAG, "Overlay permission not granted after settings returned.");
                Toast.makeText(activity, "⚠️ ওভারলে পারমিশন দেওয়া হয়নি। ভাসমান HUD বাটন বন্ধ থাকবে।", Toast.LENGTH_LONG).show();
                if (callback != null) callback.onDenied();
            }
        }
    }

    // =========================================================================
    // Device Manufacturer Quirks Detection Helpers
    // =========================================================================

    public static boolean isTecno() {
        String m = Build.MANUFACTURER != null ? Build.MANUFACTURER.toLowerCase() : "";
        String b = Build.BRAND != null ? Build.BRAND.toLowerCase() : "";
        return m.contains("tecno") || b.contains("tecno") 
                || m.contains("infinix") || b.contains("infinix") 
                || m.contains("itel") || b.contains("itel")
                || m.contains("transsion") || b.contains("transsion");
    }

    public static boolean isVivo() {
        String m = Build.MANUFACTURER != null ? Build.MANUFACTURER.toLowerCase() : "";
        String b = Build.BRAND != null ? Build.BRAND.toLowerCase() : "";
        return m.contains("vivo") || b.contains("vivo") 
                || m.contains("iqoo") || b.contains("iqoo");
    }

    public static boolean isSamsung() {
        String m = Build.MANUFACTURER != null ? Build.MANUFACTURER.toLowerCase() : "";
        String b = Build.BRAND != null ? Build.BRAND.toLowerCase() : "";
        return m.contains("samsung") || b.contains("samsung");
    }

    public static boolean isXiaomi() {
        String m = Build.MANUFACTURER != null ? Build.MANUFACTURER.toLowerCase() : "";
        String b = Build.BRAND != null ? Build.BRAND.toLowerCase() : "";
        return m.contains("xiaomi") || b.contains("xiaomi") 
                || m.contains("redmi") || b.contains("redmi")
                || m.contains("poco") || b.contains("poco");
    }
}
