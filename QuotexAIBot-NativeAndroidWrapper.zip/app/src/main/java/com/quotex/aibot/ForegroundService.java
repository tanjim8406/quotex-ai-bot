package com.quotex.aibot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/**
 * ============================================================================
 * Android 11 (API 30) Compliant Foreground Service for MediaProjection & Overlay
 * Optimized for Tecno Spark 7 (HiOS), Vivo, Samsung, and Xiaomi devices.
 *
 * CRITICAL REQUIREMENTS IMPLEMENTED:
 * 1. Calls startForeground() with a persistent Notification & NotificationChannel
 *    using ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION on Android 10+ (API 29/30).
 * 2. startForeground() is strictly executed BEFORE MediaProjectionManager.getMediaProjection().
 * 3. Handles VirtualDisplay & ImageReader screen capture buffer strides cleanly.
 * 4. Checks Settings.canDrawOverlays() before adding floating bubble view to prevent crashes.
 * 5. Passes captured Base64 frames back to MainActivity / WebView for AI analysis.
 * ============================================================================
 */
public class ForegroundService extends Service {
    private static final String TAG = "QuotexForegroundService";
    private static final String CHANNEL_ID = "quotex_mediaprojection_channel";
    private static final int NOTIFICATION_ID = 2024;

    public static final String ACTION_START = "com.quotex.aibot.ACTION_START";
    public static final String ACTION_STOP = "com.quotex.aibot.ACTION_STOP";
    public static final String ACTION_CAPTURE_NOW = "com.quotex.aibot.ACTION_CAPTURE_NOW";

    public static final String EXTRA_RESULT_CODE = "extra_result_code";
    public static final String EXTRA_DATA_INTENT = "extra_data_intent";

    private static ForegroundService instance;

    // Window & Overlay
    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private boolean isOverlayAdded = false;

    // MediaProjection Screen Capture
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private int screenWidth = 1080;
    private int screenHeight = 1920;
    private int screenDensity = 320;

    // Floating UI Views
    private TextView statusTextView;
    private TextView signalTextView;
    private ImageView botIconView;

    private boolean isCapturing = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static ForegroundService getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Log.d(TAG, "ForegroundService onCreate invoked");

        // 1. Mandatory Android 11 step: Start foreground notification immediately
        startForegroundNotification();

        // 2. Measure screen metrics for VirtualDisplay
        initScreenMetrics();

        // 3. Initialize floating bubble if overlay permission is granted
        initFloatingBubbleSafe();
    }

    /**
     * Start the mandatory Foreground Notification.
     * On Android 10+ (API 29) & Android 11 (API 30), FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
     * must be supplied to startForeground() prior to acquiring MediaProjection.
     */
    private void startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Quotex AI স্ক্রিন ক্যাপচার সার্ভিস",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("কোয়াটেক্স চার্ট স্ক্রিন ক্যাপচার ও রিয়েল-টাইম এআই সংকেত সেবা");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
                .setContentTitle("🔴 কোয়াটেক্স এআই স্ক্রিন ক্যাপচার সক্রিয়")
                .setContentText("চার্টের উপর ভাসমান বাটন চালু আছে। ট্যাপ করে সিগন্যাল নিন।")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();

        // Android 10 (Q) & Android 11 (R - API 30) Foreground Service Type requirement
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            );
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        Log.d(TAG, "startForeground completed with mediaProjection type");
    }

    private void initScreenMetrics() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth = metrics.widthPixels > 0 ? metrics.widthPixels : 1080;
            screenHeight = metrics.heightPixels > 0 ? metrics.heightPixels : 1920;
            screenDensity = metrics.densityDpi > 0 ? metrics.densityDpi : 320;
        }
    }

    /**
     * Safely initialize floating bubble view.
     * Prevents BadTokenException / SecurityException on Android 11 (Tecno Spark 7)
     * if SYSTEM_ALERT_WINDOW permission was not yet enabled.
     */
    public void initFloatingBubbleSafe() {
        if (isOverlayAdded || windowManager == null) return;

        // Check SYSTEM_ALERT_WINDOW permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Log.w(TAG, "SYSTEM_ALERT_WINDOW not granted yet. Bubble will be attached once granted.");
            return;
        }

        try {
            int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    layoutType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
            );

            params.gravity = Gravity.TOP | Gravity.START;
            params.x = 24;
            params.y = screenHeight / 3;

            LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
            if (inflater == null) return;

            floatingView = inflater.inflate(R.layout.floating_bubble_layout, null);
            statusTextView = floatingView.findViewById(R.id.tv_floating_status);
            signalTextView = floatingView.findViewById(R.id.tv_floating_signal);
            botIconView = floatingView.findViewById(R.id.iv_bot_icon);

            setupTouchListener();
            windowManager.addView(floatingView, params);
            isOverlayAdded = true;
            Log.d(TAG, "Floating overlay view successfully added to WindowManager");
        } catch (Exception e) {
            Log.e(TAG, "Failed to add floating overlay view: " + e.getMessage(), e);
        }
    }

    private void setupTouchListener() {
        if (floatingView == null) return;

        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            private long touchStartTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        touchStartTime = System.currentTimeMillis();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        if (windowManager != null && isOverlayAdded) {
                            windowManager.updateViewLayout(floatingView, params);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        long duration = System.currentTimeMillis() - touchStartTime;
                        float diffX = Math.abs(event.getRawX() - initialTouchX);
                        float diffY = Math.abs(event.getRawY() - initialTouchY);

                        // If moved less than 15 pixels within 400ms, consider it a Tap
                        if (diffX < 15 && diffY < 15 && duration < 400) {
                            handleFloatingButtonClick();
                        }
                        return true;
                }
                return false;
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Re-ensure foreground notification is alive
        startForegroundNotification();

        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_STOP.equals(action)) {
                stopSelf();
                return START_NOT_STICKY;
            } else if (ACTION_CAPTURE_NOW.equals(action)) {
                handleFloatingButtonClick();
                return START_STICKY;
            }

            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent dataIntent = intent.getParcelableExtra(EXTRA_DATA_INTENT);

            if (resultCode != 0 && dataIntent != null) {
                setupMediaProjection(resultCode, dataIntent);
            }
        }

        // Re-check overlay bubble if not yet added
        if (!isOverlayAdded) {
            initFloatingBubbleSafe();
        }

        return START_STICKY;
    }

    /**
     * Setup MediaProjection and VirtualDisplay strictly AFTER startForeground()
     */
    private void setupMediaProjection(int resultCode, Intent data) {
        MediaProjectionManager projectionManager =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        if (projectionManager != null) {
            try {
                // If previous projection exists, stop it first
                if (mediaProjection != null) {
                    try {
                        mediaProjection.stop();
                    } catch (Exception ignored) {}
                }

                mediaProjection = projectionManager.getMediaProjection(resultCode, data);

                if (mediaProjection != null) {
                    mediaProjection.registerCallback(new MediaProjection.Callback() {
                        @Override
                        public void onStop() {
                            super.onStop();
                            Log.d(TAG, "MediaProjection stopped by system");
                            if (virtualDisplay != null) {
                                virtualDisplay.release();
                                virtualDisplay = null;
                            }
                        }
                    }, mainHandler);

                    initVirtualDisplay();
                    Log.d(TAG, "MediaProjection successfully initialized on Android 11");
                }
            } catch (Exception e) {
                Log.e(TAG, "Error initializing MediaProjection: " + e.getMessage(), e);
                Toast.makeText(this, "স্ক্রিন প্রজেকশন এরর: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void initVirtualDisplay() {
        if (mediaProjection == null) return;

        try {
            if (imageReader != null) {
                imageReader.close();
            }

            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "QuotexScreenCapture",
                    screenWidth,
                    screenHeight,
                    screenDensity,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    mainHandler
            );
            Log.d(TAG, "VirtualDisplay created: " + screenWidth + "x" + screenHeight);
        } catch (Exception e) {
            Log.e(TAG, "VirtualDisplay creation failed: " + e.getMessage(), e);
        }
    }

    /**
     * User tap handler on floating bubble
     */
    private void handleFloatingButtonClick() {
        if (isCapturing) return;
        isCapturing = true;

        if (statusTextView != null) {
            statusTextView.setText("📸 কোয়াটেক্স চার্ট ক্যাপচার হচ্ছে...");
        }

        // 150ms delay to allow animations to settle
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                captureAndSendScreenFrame();
            }
        }, 150);
    }

    /**
     * Captures current frame from ImageReader, crops buffer stride padding,
     * encodes to Base64 JPEG, and transmits it directly to WebView.
     */
    private void captureAndSendScreenFrame() {
        if (imageReader == null) {
            Toast.makeText(this, "স্ক্রিন ক্যাপচার সার্ভিস প্রস্তুত নয়। পুনরায় পারমিশন দিন।", Toast.LENGTH_SHORT).show();
            isCapturing = false;
            return;
        }

        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                image = imageReader.acquireNextImage();
            }

            if (image != null) {
                Image.Plane[] planes = image.getPlanes();
                ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                int rowPadding = rowStride - pixelStride * screenWidth;

                Bitmap bitmap = Bitmap.createBitmap(
                        screenWidth + rowPadding / pixelStride,
                        screenHeight,
                        Bitmap.Config.ARGB_8888
                );
                bitmap.copyPixelsFromBuffer(buffer);

                // Crop out padding to exact screen bounds
                Bitmap cleanBitmap = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
                if (cleanBitmap != bitmap) {
                    bitmap.recycle();
                }

                // Compress to Base64 JPEG (Quality 85%)
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                cleanBitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream);
                byte[] byteArray = stream.toByteArray();
                String base64Image = Base64.encodeToString(byteArray, Base64.NO_WRAP);
                cleanBitmap.recycle();

                // Send frame directly to WebView
                MainActivity.sendFrameToWebView(base64Image);

                if (statusTextView != null) {
                    statusTextView.setText("🧠 এআই অ্যানালাইসিস চলছে...");
                }
            } else {
                Toast.makeText(this, "স্ক্রিন ফ্রেম পাওয়া যায়নি, পুনরায় ট্যাপ করুন।", Toast.LENGTH_SHORT).show();
                if (statusTextView != null) {
                    statusTextView.setText("👆 ট্যাপ করে স্ক্যান করুন");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Screen capture error: " + e.getMessage(), e);
            Toast.makeText(this, "ক্যাপচার এরর: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            if (image != null) {
                image.close();
            }
            isCapturing = false;
        }
    }

    public static void triggerScreenCapture() {
        if (instance != null) {
            instance.handleFloatingButtonClick();
        }
    }

    /**
     * Updates floating bubble banner with live AI signal received from the Web App
     */
    public static void updateSignalDisplay(final String jsonString) {
        if (instance == null || instance.statusTextView == null || instance.signalTextView == null) {
            return;
        }

        instance.mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject json = new JSONObject(jsonString);
                    String recommendation = json.optString("recommendation", "CALL");
                    int confidence = json.optInt("confidencePercent", 95);
                    String voice = json.optString("voiceAnnouncementBengali", "");

                    boolean isCall = "CALL".equalsIgnoreCase(recommendation);
                    boolean isPut = "PUT".equalsIgnoreCase(recommendation);
                    boolean isDanger = "DO_NOT_TRADE".equalsIgnoreCase(recommendation);

                    if (isDanger) {
                        String condition = json.optString("marketCondition", "ফেক মার্কেট ট্র্যাপ");
                        instance.signalTextView.setText("⛔ ট্রেড সম্পূর্ণ নিষিদ্ধ!");
                        instance.signalTextView.setTextColor(Color.parseColor("#EF4444"));
                        instance.statusTextView.setText("⚠️ " + (condition.length() > 22 ? condition.substring(0, 22) + "..." : condition));
                    } else if (isCall) {
                        instance.signalTextView.setText("▲ CALL (UP 🟢)");
                        instance.signalTextView.setTextColor(Color.parseColor("#00E676"));
                        instance.statusTextView.setText("নিশ্চয়তা: " + confidence + "% | মেয়াদ: ১ মিনিট");
                    } else if (isPut) {
                        instance.signalTextView.setText("▼ PUT (DOWN 🔴)");
                        instance.signalTextView.setTextColor(Color.parseColor("#FF1744"));
                        instance.statusTextView.setText("নিশ্চয়তা: " + confidence + "% | মেয়াদ: ১ মিনিট");
                    }

                    // Speak Bengali voice alert
                    MainActivity mainActivity = MainActivity.getInstance();
                    if (mainActivity != null && !voice.isEmpty()) {
                        mainActivity.speakBengali(voice);
                    }

                } catch (Exception e) {
                    Log.e(TAG, "Signal parse error: " + e.getMessage(), e);
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        Log.d(TAG, "ForegroundService onDestroy");

        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        if (floatingView != null && windowManager != null && isOverlayAdded) {
            try {
                windowManager.removeView(floatingView);
            } catch (Exception ignored) {}
            isOverlayAdded = false;
        }
    }
}
